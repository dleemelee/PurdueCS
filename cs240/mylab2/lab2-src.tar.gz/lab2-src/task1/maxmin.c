#include <stdio.h>
//

int main(int argc, char **argv) {
        printf("Finding maximum among three numbers a,b and c\n");
         // Write your implementation here...
	return 0;
}


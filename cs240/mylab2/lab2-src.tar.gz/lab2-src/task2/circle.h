#define PI 3.14
double const pi = PI;

#include <stdio.h>
#include "circle.h"
//

int main(int argc, char **argv) {

        printf("Finding area and circumference of a circle given a radius\n");
        // Write your implementation here...
	return 0;
}


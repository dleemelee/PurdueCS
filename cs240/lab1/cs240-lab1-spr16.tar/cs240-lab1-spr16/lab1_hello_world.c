/*
 *  Intro_prog1 -- Introductory program for CS 240 
 *
 *  This program simply prints a simple message
 *  "Hello, world and <name>!"
 *
 *  The student should use an editor to replace <name>
 *  with her or his name, compile this program, and run it.
 *
 */

#include <stdio.h>

int main()
{
	printf("Hello, world and <name>!\n");
	return 0;
}

/* 
 *  lab1_temp_cnvt_hdr.h -- include file for 2nd introductory program
 *
 *  We declare two functions, F_to_C and C_to_F
 *
 */


float F_to_C (float fahr);

float C_to_F (float cent);
